"use strict";
var $foreign = require("./foreign");
var Control_Applicative = require("../Control.Applicative");
var Control_Bind = require("../Control.Bind");
var Control_Monad_Eff = require("../Control.Monad.Eff");
var Data_Function = require("../Data.Function");
var Data_Functor = require("../Data.Functor");
var Data_Maybe = require("../Data.Maybe");
var Data_Unit = require("../Data.Unit");
var Draw_Cube = require("../Draw.Cube");
var Draw_MouseIntegration = require("../Draw.MouseIntegration");
var Draw_Samples = require("../Draw.Samples");
var Graphics_Canvas = require("../Graphics.Canvas");
var Partial_Unsafe = require("../Partial.Unsafe");
var Prelude = require("../Prelude");
var main = Data_Functor["void"](Control_Monad_Eff.functorEff)(function __do() {
    var v = Graphics_Canvas.getCanvasElementById("one")();
    var __unused = function (dictPartial1) {
        return function ($dollar3) {
            return $dollar3;
        };
    };
    return __unused()((function () {
        if (v instanceof Data_Maybe.Just) {
            return function __do() {
                var v1 = Graphics_Canvas.getContext2D(v.value0)();
                $foreign.addEvents(v1)("mouseup")(Draw_MouseIntegration.onMouseRelease)();
                $foreign.addEvents(v1)("mousedown")(Draw_MouseIntegration.onMouseclick)();
                $foreign.addEvents(v1)("mousemove")(Draw_MouseIntegration.onMouseMove)();
                $foreign.tim(v1)(Draw_Cube.cha_draw);
                return Data_Unit.unit;
            };
        };
        throw new Error("Failed pattern match at Main line 22, column 3 - line 23, column 3: " + [ v.constructor.name ]);
    })())();
});
module.exports = {
    main: main,
    tim: $foreign.tim,
    addEvents: $foreign.addEvents
};
