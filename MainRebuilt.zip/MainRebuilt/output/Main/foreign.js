"use strict";

exports.tim = function(ctx){
  return function(callb){
    function loop(val){
     callb(ctx)();
     //callb(ctx)(360.0)();
      window.requestAnimationFrame(loop);
    }

    window.requestAnimationFrame(loop);
    return function() {};
  }
}

exports.addEvents= function(ctx){
  ctx.rect(0, 0, 1000, 1000);
  ctx.fillStyle = "blue";
  return function(evt){
    var m_p=" ";
    return function(callb){
      function eventHandler(e){
        m_p=m_p+"{"+e.clientX+","+e.clientY+"}";
        document.getElementById("mar1").innerHTML = m_p;
        callb(e)();document.getElementById("mar").innerHTML = "{"+e.clientX+","+e.clientY+"}";
      }
      one.addEventListener(evt,eventHandler);console.log(evt);
      return function(){};
    }
  }
}
