"use strict";
var Control_Applicative = require("../Control.Applicative");
var Control_Bind = require("../Control.Bind");
var Control_Monad_Eff = require("../Control.Monad.Eff");
var Data_EuclideanRing = require("../Data.EuclideanRing");
var Data_Foldable = require("../Data.Foldable");
var Data_Function = require("../Data.Function");
var Data_Functor = require("../Data.Functor");
var Data_Maybe = require("../Data.Maybe");
var Data_Ord = require("../Data.Ord");
var Data_Ring = require("../Data.Ring");
var Data_Semiring = require("../Data.Semiring");
var Data_Unit = require("../Data.Unit");
var Draw_MouseIntegration = require("../Draw.MouseIntegration");
var DrawExtras = require("../DrawExtras");
var FFI_Util = require("../FFI.Util");
var Graphics_Canvas = require("../Graphics.Canvas");
var $$Math = require("../Math");
var Partial_Unsafe = require("../Partial.Unsafe");
var Prelude = require("../Prelude");
var draw = function (ctx) {
    return function (ang) {
        return Data_Functor["void"](Control_Monad_Eff.functorEff)(function __do() {
            var v = Graphics_Canvas.setStrokeStyle("#FF0000")(ctx)();
            var vertex1 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: -0.5,
                y: -0.5,
                z: -0.5
            })(ang));
            var vertex2 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: 0.5,
                y: -0.5,
                z: -0.5
            })(ang));
            var vertex3 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: 0.5,
                y: 0.5,
                z: -0.5
            })(ang));
            var vertex4 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: -0.5,
                y: 0.5,
                z: -0.5
            })(ang));
            var vertex5 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: -0.5,
                y: -0.5,
                z: 0.5
            })(ang));
            var vertex6 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: 0.5,
                y: -0.5,
                z: 0.5
            })(ang));
            var vertex7 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: 0.5,
                y: 0.5,
                z: 0.5
            })(ang));
            var vertex8 = DrawExtras.cent(DrawExtras.updatepointwithangle({
                x: -0.5,
                y: 0.5,
                z: 0.5
            })(ang));
            DrawExtras.makealine(ctx)(vertex1)(vertex2)();
            DrawExtras.makealine(ctx)(vertex2)(vertex3)();
            DrawExtras.makealine(ctx)(vertex3)(vertex4)();
            DrawExtras.makealine(ctx)(vertex4)(vertex1)();
            DrawExtras.makealine(ctx)(vertex5)(vertex6)();
            DrawExtras.makealine(ctx)(vertex6)(vertex7)();
            DrawExtras.makealine(ctx)(vertex7)(vertex8)();
            DrawExtras.makealine(ctx)(vertex8)(vertex5)();
            DrawExtras.makealine(ctx)(vertex1)(vertex5)();
            DrawExtras.makealine(ctx)(vertex2)(vertex6)();
            DrawExtras.makealine(ctx)(vertex3)(vertex7)();
            return DrawExtras.makealine(ctx)(vertex4)(vertex8)();
        });
    };
};

// makealine ctx vertex1 vertex9
// makealine ctx vertex9 vertex2
var cha_draw = function (ctx) {
    return Data_Functor["void"](Control_Monad_Eff.functorEff)((function () {
        var v = FFI_Util.property(Draw_MouseIntegration.acceleration)("0");
        return function __do() {
            var v1 = (function () {
                var $10 = v > 0.0;
                if ($10) {
                    return function __do() {
                        var v1 = FFI_Util.setProperty(Draw_MouseIntegration.acceleration)("0")(FFI_Util.property(Draw_MouseIntegration.acceleration)("0") - 0.5);
                        var v2 = FFI_Util.property(Draw_MouseIntegration.deltaMove)("x");
                        var v3 = FFI_Util.property(Draw_MouseIntegration.deltaMove)("y");
                        FFI_Util.setProperty(Draw_MouseIntegration.rotation)("x")(FFI_Util.property(Draw_MouseIntegration.rotation)("x") - v3);
                        FFI_Util.setProperty(Draw_MouseIntegration.rotation)("y")(FFI_Util.property(Draw_MouseIntegration.rotation)("y") - v2);
                        return Data_Unit.unit;
                    };
                };
                return Control_Applicative.pure(Control_Monad_Eff.applicativeEff)(Data_Unit.unit);
            })()();
            var ang = {
                x: (FFI_Util.property(Draw_MouseIntegration.rotation)("x") * $$Math.pi) / 180.0,
                y: (FFI_Util.property(Draw_MouseIntegration.rotation)("y") * $$Math.pi) / 180.0,
                z: 0.0
            };
            var v2 = Graphics_Canvas.setFillStyle("#FFF000")(ctx)();
            var v3 = Graphics_Canvas.fillRect(ctx)({
                x: 0.0,
                y: 0.0,
                w: 1000.0,
                h: 1000.0
            })();
            var v4 = draw(ctx)(ang)();
            return Data_Unit.unit;
        };
    })());
};
module.exports = {
    draw: draw,
    cha_draw: cha_draw
};
