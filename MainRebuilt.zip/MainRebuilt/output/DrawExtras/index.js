"use strict";
var Control_Applicative = require("../Control.Applicative");
var Control_Bind = require("../Control.Bind");
var Control_Monad_Eff = require("../Control.Monad.Eff");
var Data_Function = require("../Data.Function");
var Data_Functor = require("../Data.Functor");
var Data_Maybe = require("../Data.Maybe");
var Data_Ring = require("../Data.Ring");
var Data_Semiring = require("../Data.Semiring");
var Data_Unit = require("../Data.Unit");
var Graphics_Canvas = require("../Graphics.Canvas");
var $$Math = require("../Math");
var Partial_Unsafe = require("../Partial.Unsafe");
var Prelude = require("../Prelude");
var Vertex = function (x) {
    return x;
};
var updatepointwithangle = function (v) {
    return function (v1) {
        
        //Vector3  { x: vec.x, y: rty, z:rtz }
        //Y Rotation
var ysinA = $$Math.sin(v1.y);
        var ycosA = $$Math.cos(v1.y);
        
        //X Rotation
var sinA = $$Math.sin(v1.x);
        var cosA = $$Math.cos(v1.x);
        var rty = v.y * cosA - v.z * sinA;
        var rtz = v.y * sinA + v.z * cosA;
        var yrtx = v.x * ycosA + rtz * ysinA;
        var yrtz = -v.x * ysinA + rtz * ycosA;
        return {
            x: yrtx,
            y: rty,
            z: yrtz
        };
    };
};
var makealine = function (ctx) {
    return function (v) {
        return function (v1) {
            return Data_Functor["void"](Control_Monad_Eff.functorEff)(function __do() {
                var v2 = Graphics_Canvas.beginPath(ctx)();
                var v3 = Graphics_Canvas.setFillStyle("#00FF00")(ctx)();
                var v4 = Graphics_Canvas.moveTo(ctx)(v.x)(v.y)();
                var v5 = Graphics_Canvas.lineTo(ctx)(v1.x)(v1.y)();
                var v6 = Graphics_Canvas.setLineWidth(10.0)(ctx)();
                var v7 = Graphics_Canvas.setShadowColor("#000000")(ctx)();
                var v8 = Graphics_Canvas.stroke(ctx)();
                var v9 = Graphics_Canvas.closePath(ctx)();
                return Data_Unit.unit;
            });
        };
    };
};
var cent = function (v) {
    return {
        x: v.x * 280.0 + 280.0,
        y: v.y * 280.0 + 280.0,
        z: v.z
    };
};
module.exports = {
    Vertex: Vertex,
    cent: cent,
    makealine: makealine,
    updatepointwithangle: updatepointwithangle
};
